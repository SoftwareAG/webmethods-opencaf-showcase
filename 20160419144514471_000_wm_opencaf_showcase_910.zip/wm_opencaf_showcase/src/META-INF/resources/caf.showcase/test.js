function showcaseTest() {
	CAF.Dialog.alert("hello from javascript file loaded from resource library!", null, {id:'showcaseTest'});
	return false;
}
