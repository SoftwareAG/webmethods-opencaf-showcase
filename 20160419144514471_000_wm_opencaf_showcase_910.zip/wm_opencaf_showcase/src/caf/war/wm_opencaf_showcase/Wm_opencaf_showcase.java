/**
 * 
 */
package caf.war.wm_opencaf_showcase;

/**
 * @author administrator
 *
 */
public class Wm_opencaf_showcase extends com.webmethods.caf.faces.bean.BaseApplicationBean 
{
	public Wm_opencaf_showcase()
	{
		super();
		setCategoryName( "CafApplication" );
		setSubCategoryName( "wm_opencaf_showcase" );
	}
}